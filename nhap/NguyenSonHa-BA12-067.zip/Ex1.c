#include <stdio.h>
#include <stdlib.h>

int binarySearch(int arr[], int size, int value) {
    int low = 0, high = size - 1;
    while (low <= high) {
        int mid = (low + high) / 2;
        if (arr[mid] == value) {
            return mid;
        }
        if (arr[mid] < value) {
            low = mid + 1;
        }
        else {
            high = mid - 1;
        }
    }
    return -1;
}

int main() {
    int data[] = {1, 2, 3, 5, 6, 7};
    int size = sizeof(data) / sizeof(data[0]);
    int v;
    printf("Enter a new value: ");
    scanf("%d", &v);

    int* newArr = (int*) malloc((size + 1) * sizeof(int));
    for (int i = 0; i < size; i++) {
        newArr[i] = data[i];
    }
    newArr[size] = v;

    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size + 1; j++) {
            if (newArr[i] > newArr[j]) {
                int temp = newArr[i];
                newArr[i] = newArr[j];
                newArr[j] = temp;
            }
        }
    }

    printf("Array when added new value: ");
    for (int i = 0; i < size + 1; i++) {
        printf("%d ", newArr[i]);
    }
    free(newArr);

    int result = binarySearch(newArr, size + 1, v);
    if (result == -1) {
        printf("\nNot found in array");
    }
    else {
        printf("\nItem is found at index %d", result);
    }

    return 0;
}